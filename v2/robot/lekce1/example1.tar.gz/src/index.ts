import { LED_WS2812B, SmartLed } from "smartled"
import { createRobutek } from "./libs/robutek.js"
import * as colors from "./libs/colors.js";
const robutek = createRobutek("V2");

const ledStrip = new SmartLed(robutek.Pins.ILED, 1, LED_WS2812B);

ledStrip.clear(); // Zhasne LEDku na Robůtkovi, jenom pro jistotu, kdyby už předtím svítila
ledStrip.set(0, colors.red); // Nastaví první LEDku na červenou barvu, LEDky začínají na indexu 0
ledStrip.show(); // Rozsvítí LEDku s červenou, kterou jsme si nastavili

setInterval(() => { // pravidelně vyvolává událost
  console.log("Robotický tábor 2025, zdraví Jirka Vácha!"); // vypíše text: Robotický tábor 2025, zdraví Jirka Vácha!
}, 1000); // čas opakování se udává v milisekundách (1000 ms je 1 sekunda)
